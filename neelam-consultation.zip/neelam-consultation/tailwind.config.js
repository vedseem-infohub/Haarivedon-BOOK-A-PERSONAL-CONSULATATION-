/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        cream: { 50: '#FFFDF8', 100: '#FBF6EC', 200: '#F5EBD7', 300: '#EBDCBC' },
        gold: { 300: '#E5C97E', 400: '#D4AF5F', 500: '#C29A45', 600: '#A47E2E', 700: '#7F611F' },
        maroon: { 50: '#FBF0F1', 100: '#F3DADD', 500: '#8E2A37', 600: '#7A1F2B', 700: '#621722', 800: '#4A101A', 900: '#330A11' },
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 10px 40px -12px rgba(122, 31, 43, 0.18)',
        gold: '0 8px 24px -8px rgba(194, 154, 69, 0.55)',
      },
      keyframes: {
        fadeUp: { '0%': { opacity: 0, transform: 'translateY(12px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
      },
      animation: { fadeUp: 'fadeUp 0.45s ease-out both' },
    },
  },
  plugins: [],
}

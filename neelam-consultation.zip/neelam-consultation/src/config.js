export const NAME = 'Neelam Ajay Singh'
export const BRAND = 'HaarivedOn'
export const ROLE = `Astrologer, ${BRAND}`
export const EXPERIENCE = '15+'
export const SITE_URL = 'https://webinar.haarivedon.com'

export const CALENDLY_URL = 'https://calendly.com/harivedon/30min'
export const RAZORPAY_URL = 'https://rzp.io/rzp/M54zKjPB'
export const FEE = '₹501'
export const DURATION = '30 minutes'

export const TOPICS = [
  'Career / Job',
  'Business / Finance',
  'Marriage / Relationship',
  'Family Problems',
  'Future / Personal Life',
  'Spiritual Guidance / Remedies',
  'Other',
]

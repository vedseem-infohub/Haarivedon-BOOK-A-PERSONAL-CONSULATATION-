import { BRAND, DURATION, EXPERIENCE, FEE, NAME } from '../config.js'
import { scrollToBooking } from '../scroll.js'

const AREAS = [
  { icon: '✦', title: 'Career / Job', text: 'Direction on career choices, job changes, and professional growth.' },
  { icon: '❖', title: 'Business / Finance', text: 'Guidance on business decisions and financial concerns.' },
  { icon: '❤', title: 'Marriage / Relationship', text: 'Clarity on marriage, compatibility, and relationships.' },
  { icon: '⌂', title: 'Family Problems', text: 'Support in understanding and easing family situations.' },
  { icon: '☼', title: 'Future / Personal Life', text: 'Insight into the path ahead and personal questions.' },
  { icon: 'ॐ', title: 'Spiritual Guidance / Remedies', text: 'Suggestions and suitable remedies for your situation.' },
]

const STEPS = [
  { title: 'Share your details', text: 'Answer eight short questions about yourself, your concern, and your birth details.' },
  { title: 'Choose a time', text: 'Pick an available date and time on Calendly for your 30-minute consultation.' },
  { title: `Pay ${FEE}`, text: 'Complete the consultation fee securely on Razorpay.' },
  { title: 'Attend your consultation', text: `Discuss your concerns one-on-one with ${NAME}.` },
]

export default function About() {
  return (
    <>
      <section id="about" className="bg-white px-6 py-16 md:py-24">
        <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-gold-600">About</p>
            <h2 className="mt-3 text-4xl font-semibold text-maroon-700 md:text-5xl">Meet {NAME}</h2>
            <div className="mt-4 h-px w-24 bg-gold-400" />
            <p className="mt-6 text-lg leading-relaxed text-maroon-900/75">
              {NAME} is an astrologer with {BRAND}, with more than {EXPERIENCE.replace('+', '')} years of experience
              guiding people through questions about their career, business, marriage, family, and personal life.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-maroon-900/75">
              Every consultation is a personal, one-on-one conversation. Based on your concern and birth details, she
              listens carefully and shares personalized guidance, practical suggestions, and suitable remedies to help
              you move forward with clarity.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <AboutStat value={EXPERIENCE} label="Years of experience" wide />
            <AboutStat value="30" label={`Minute personal consultation`} />
            <AboutStat value={FEE} label="Consultation fee" />
            <AboutStat value="1:1" label="Private, personal session" wide />
          </div>
        </div>
      </section>

      <section className="bg-cream-200/60 px-6 py-16 md:py-24">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-gold-600">Areas of guidance</p>
            <h2 className="mt-3 text-4xl font-semibold text-maroon-700 md:text-5xl">How a Consultation Can Help</h2>
            <div className="mx-auto mt-4 h-px w-24 bg-gold-400" />
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {AREAS.map((a) => (
              <div key={a.title} className="card p-6 transition hover:-translate-y-1">
                <span aria-hidden className="flex h-12 w-12 items-center justify-center rounded-full bg-maroon-600 text-xl text-gold-300">
                  {a.icon}
                </span>
                <h3 className="mt-4 text-2xl font-semibold text-maroon-700">{a.title}</h3>
                <p className="mt-2 text-maroon-900/70">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-maroon-700 px-6 py-16 text-cream-100 md:py-24">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-gold-300">Simple process</p>
            <h2 className="mt-3 text-4xl font-semibold text-cream-50 md:text-5xl">How Booking Works</h2>
            <div className="mx-auto mt-4 h-px w-24 bg-gold-400" />
          </div>
          <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <li key={s.title} className="rounded-3xl border border-gold-400/30 bg-maroon-800/50 p-6">
                <span className="font-serif text-4xl font-semibold text-gold-300">0{i + 1}</span>
                <h3 className="mt-3 text-2xl font-semibold text-cream-50">{s.title}</h3>
                <p className="mt-2 text-cream-100/75">{s.text}</p>
              </li>
            ))}
          </ol>
          <div className="mt-12 text-center">
            <button type="button" onClick={scrollToBooking} className="btn-gold text-lg">
              Book Your Personal Consultation
            </button>
            <p className="mt-3 text-sm text-cream-100/70">
              {DURATION} · {FEE}
            </p>
          </div>
        </div>
      </section>
    </>
  )
}

function AboutStat({ value, label, wide }) {
  return (
    <div className={`rounded-3xl border border-gold-300/50 p-6 text-center ${wide ? 'bg-maroon-600 text-cream-50' : 'bg-cream-100'}`}>
      <p className={`font-serif text-5xl font-semibold ${wide ? 'text-gold-300' : 'text-maroon-700'}`}>{value}</p>
      <p className={`mt-2 text-sm ${wide ? 'text-cream-100/85' : 'text-maroon-900/65'}`}>{label}</p>
    </div>
  )
}

import { useEffect, useRef, useState } from 'react'

const SCRIPT_SRC = 'https://assets.calendly.com/assets/external/widget.js'

function loadCalendlyScript() {
  if (window.Calendly) return Promise.resolve()
  let script = document.querySelector(`script[src="${SCRIPT_SRC}"]`)
  return new Promise((resolve, reject) => {
    if (!script) {
      script = document.createElement('script')
      script.src = SCRIPT_SRC
      script.async = true
      document.body.appendChild(script)
    }
    script.addEventListener('load', () => resolve())
    script.addEventListener('error', () => reject(new Error('Calendly failed to load')))
  })
}

export default function CalendlyEmbed({ url, onScheduled }) {
  const containerRef = useRef(null)
  const [status, setStatus] = useState('loading')

  useEffect(() => {
    let cancelled = false
    loadCalendlyScript()
      .then(() => {
        if (cancelled || !containerRef.current) return
        containerRef.current.innerHTML = ''
        window.Calendly.initInlineWidget({ url, parentElement: containerRef.current })
        setStatus('ready')
      })
      .catch(() => !cancelled && setStatus('error'))
    return () => {
      cancelled = true
    }
  }, [url])

  useEffect(() => {
    const handler = (e) => {
      if (e.origin !== 'https://calendly.com') return
      if (e.data?.event === 'calendly.event_scheduled') onScheduled?.(e.data.payload)
    }
    window.addEventListener('message', handler)
    return () => window.removeEventListener('message', handler)
  }, [onScheduled])

  return (
    <div className="relative overflow-hidden rounded-2xl border border-cream-300 bg-white">
      {status === 'loading' && (
        <div className="absolute inset-0 flex items-center justify-center text-maroon-900/60">
          <span className="mr-3 h-5 w-5 animate-spin rounded-full border-2 border-gold-400 border-t-transparent" />
          Loading available times…
        </div>
      )}
      {status === 'error' && (
        <div className="p-8 text-center">
          <p className="text-maroon-700">The scheduling calendar could not be loaded here.</p>
          <a href={url} target="_blank" rel="noopener noreferrer" className="btn-outline mt-4">
            Open Calendly in a new tab
          </a>
        </div>
      )}
      <div ref={containerRef} className="h-[1050px] w-full md:h-[720px]" />
    </div>
  )
}

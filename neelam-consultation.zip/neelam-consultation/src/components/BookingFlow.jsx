import { useCallback, useEffect, useRef, useState } from 'react'
import { CALENDLY_URL, DURATION, FEE, NAME, RAZORPAY_URL, TOPICS } from '../config.js'
import CalendlyEmbed from './CalendlyEmbed.jsx'
import { Check, ExternalLink } from './Icons.jsx'

const STEPS = ['Personal', 'Consultation', 'Birth Details', 'Schedule', 'Payment']
const STEP = { PERSONAL: 0, CONSULTATION: 1, BIRTH: 2, SCHEDULE: 3, PAYMENT: 4, CONFIRMATION: 5 }

const INITIAL = {
  fullName: '',
  whatsapp: '',
  email: '',
  topics: [],
  concern: '',
  dob: '',
  birthTime: '',
  birthPlace: '',
}

const todayISO = () => {
  const d = new Date()
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset())
  return d.toISOString().slice(0, 10)
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

function validateStep(step, v) {
  const e = {}
  if (step === STEP.PERSONAL) {
    if (v.fullName.trim().length < 2) e.fullName = 'Please enter your full name.'
    const digits = v.whatsapp.replace(/\D/g, '')
    if (!v.whatsapp.trim()) e.whatsapp = 'Please enter your WhatsApp number.'
    else if (!/^\+?[\d\s()-]+$/.test(v.whatsapp.trim()) || digits.length < 10 || digits.length > 15)
      e.whatsapp = 'Please enter a valid WhatsApp number (10–15 digits, country code optional).'
    if (!v.email.trim()) e.email = 'Please enter your email address.'
    else if (!EMAIL_RE.test(v.email.trim())) e.email = 'Please enter a valid email address.'
  }
  if (step === STEP.CONSULTATION) {
    if (v.topics.length === 0) e.topics = 'Please select at least one area of life.'
    if (v.concern.trim().length < 20)
      e.concern = 'Please describe your concern in a little more detail (at least 20 characters).'
  }
  if (step === STEP.BIRTH) {
    if (!v.dob) e.dob = 'Please select your date of birth.'
    else if (v.dob > todayISO()) e.dob = 'Date of birth cannot be in the future.'
    if (!v.birthTime) e.birthTime = 'Please select your birth time.'
    if (v.birthPlace.trim().length < 2) e.birthPlace = 'Please enter your place of birth.'
  }
  return e
}

const formatDate = (iso) =>
  iso ? new Date(`${iso}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : ''

const formatTime = (t) => {
  if (!t) return ''
  const [h, m] = t.split(':').map(Number)
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`
}

function Field({ id, label, number, error, hint, children }) {
  return (
    <div>
      <label htmlFor={id} className="block font-medium text-maroon-800">
        <span className="mr-2 font-serif text-lg text-gold-600">{number}.</span>
        {label} <span className="text-maroon-500" aria-hidden>*</span>
      </label>
      {hint && <p className="mt-1 text-sm text-maroon-900/55">{hint}</p>}
      {children}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-2 text-sm font-medium text-maroon-600">
          {error}
        </p>
      )}
    </div>
  )
}

function ProgressBar({ step }) {
  const current = Math.min(step, STEP.PAYMENT)
  return (
    <nav aria-label="Booking progress" className="mb-10">
      <ol className="flex items-center">
        {STEPS.map((label, i) => {
          const done = i < current || step === STEP.CONFIRMATION
          const active = i === current && step !== STEP.CONFIRMATION
          return (
            <li key={label} className={`flex items-center ${i < STEPS.length - 1 ? 'flex-1' : ''}`}>
              <div className="flex flex-col items-center gap-2">
                <span
                  aria-current={active ? 'step' : undefined}
                  className={`flex h-9 w-9 items-center justify-center rounded-full border-2 text-sm font-semibold transition-all duration-300 ${
                    done
                      ? 'border-maroon-600 bg-maroon-600 text-cream-50'
                      : active
                        ? 'border-gold-500 bg-gold-400/20 text-maroon-700 ring-4 ring-gold-300/30'
                        : 'border-cream-300 bg-white text-maroon-900/40'
                  }`}
                >
                  {done ? <Check className="h-4 w-4" /> : i + 1}
                </span>
                <span
                  className={`hidden text-xs font-medium sm:block ${active || done ? 'text-maroon-700' : 'text-maroon-900/40'}`}
                >
                  {label}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div className="mx-2 h-0.5 flex-1 rounded bg-cream-300 sm:mb-6">
                  <div
                    className="h-full rounded bg-maroon-600 transition-all duration-500"
                    style={{ width: done ? '100%' : '0%' }}
                  />
                </div>
              )}
            </li>
          )
        })}
      </ol>
      <p className="mt-4 text-center text-sm text-maroon-900/60 sm:hidden">
        Step {current + 1} of {STEPS.length}: {STEPS[current]}
      </p>
    </nav>
  )
}

function SummaryRow({ label, value }) {
  return (
    <div className="grid gap-1 border-b border-cream-200 py-3 last:border-0 sm:grid-cols-[180px_1fr] sm:gap-4">
      <dt className="text-sm font-medium text-maroon-900/55">{label}</dt>
      <dd className="break-words text-maroon-900">{value}</dd>
    </div>
  )
}

export default function BookingFlow() {
  const [step, setStep] = useState(STEP.PERSONAL)
  const [values, setValues] = useState(INITIAL)
  const [errors, setErrors] = useState({})
  const [scheduledViaCalendly, setScheduledViaCalendly] = useState(false)
  const [manualScheduleConfirm, setManualScheduleConfirm] = useState(false)
  const sectionRef = useRef(null)
  const prevStep = useRef(step)

  useEffect(() => {
    if (prevStep.current === step) return
    prevStep.current = step
    sectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [step])

  const set = (name, value) => {
    setValues((v) => ({ ...v, [name]: value }))
    if (errors[name]) setErrors((e) => ({ ...e, [name]: undefined }))
  }

  const toggleTopic = (topic) => {
    set('topics', values.topics.includes(topic) ? values.topics.filter((t) => t !== topic) : [...values.topics, topic])
  }

  const next = () => {
    const e = validateStep(step, values)
    setErrors(e)
    if (Object.keys(e).length) {
      const first = Object.keys(e)[0]
      document.getElementById(first === 'topics' ? 'topic-0' : first)?.focus()
      return
    }
    setStep((s) => s + 1)
  }

  const back = () => {
    setErrors({})
    setStep((s) => Math.max(0, s - 1))
  }

  const handleScheduled = useCallback(() => setScheduledViaCalendly(true), [])
  const canContinueToPayment = scheduledViaCalendly || manualScheduleConfirm

  const inputProps = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange: (e) => set(name, e.target.value),
    'aria-invalid': errors[name] ? true : undefined,
    'aria-describedby': errors[name] ? `${name}-error` : undefined,
    className: `field-input ${errors[name] ? 'field-error' : ''}`,
  })

  const isFormStep = step <= STEP.BIRTH

  return (
    <section id="booking" ref={sectionRef} className="scroll-mt-4 bg-cream-100 px-4 py-16 md:py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-10 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-gold-600">Book your session</p>
          <h2 className="mt-3 text-4xl font-semibold text-maroon-700 md:text-5xl">Personal Consultation Booking</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gold-400" />
        </div>

        <div className="card p-6 sm:p-10">
          <ProgressBar step={step} />

          {isFormStep && (
            <form
              noValidate
              onSubmit={(e) => {
                e.preventDefault()
                next()
              }}
            >
              <div key={step} className="animate-fadeUp space-y-7">
                {step === STEP.PERSONAL && (
                  <>
                    <StepHeading title="Personal details" subtitle="Tell us how we can reach you." />
                    <Field id="fullName" number={1} label="What is your full name?" error={errors.fullName}>
                      <input type="text" autoComplete="name" placeholder="Your full name" {...inputProps('fullName')} />
                    </Field>
                    <Field id="whatsapp" number={2} label="What is your WhatsApp number?" error={errors.whatsapp}>
                      <input
                        type="tel"
                        inputMode="tel"
                        autoComplete="tel"
                        placeholder="+91 98765 43210"
                        {...inputProps('whatsapp')}
                      />
                    </Field>
                    <Field id="email" number={3} label="What is your email address?" error={errors.email}>
                      <input type="email" autoComplete="email" placeholder="you@example.com" {...inputProps('email')} />
                    </Field>
                  </>
                )}

                {step === STEP.CONSULTATION && (
                  <>
                    <StepHeading title="Consultation details" subtitle={`Help ${NAME} understand your concern.`} />
                    <fieldset aria-describedby={errors.topics ? 'topics-error' : undefined}>
                      <legend className="font-medium text-maroon-800">
                        <span className="mr-2 font-serif text-lg text-gold-600">4.</span>
                        Which area of life do you need guidance about?{' '}
                        <span className="text-maroon-500" aria-hidden>*</span>
                      </legend>
                      <p className="mt-1 text-sm text-maroon-900/55">Select all that apply.</p>
                      <div className="mt-3 grid gap-3 sm:grid-cols-2">
                        {TOPICS.map((topic, i) => {
                          const checked = values.topics.includes(topic)
                          return (
                            <label
                              key={topic}
                              className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 transition ${
                                checked
                                  ? 'border-gold-500 bg-gold-400/10 text-maroon-800'
                                  : 'border-cream-300 bg-cream-50 hover:border-gold-400'
                              }`}
                            >
                              <input
                                id={`topic-${i}`}
                                type="checkbox"
                                checked={checked}
                                onChange={() => toggleTopic(topic)}
                                className="h-5 w-5 rounded border-cream-300 accent-maroon-600"
                              />
                              <span>{topic}</span>
                            </label>
                          )
                        })}
                      </div>
                      {errors.topics && (
                        <p id="topics-error" role="alert" className="mt-2 text-sm font-medium text-maroon-600">
                          {errors.topics}
                        </p>
                      )}
                    </fieldset>
                    <Field
                      id="concern"
                      number={5}
                      label="Please describe your concern or situation in detail."
                      error={errors.concern}
                    >
                      <textarea rows={6} placeholder="Share what is on your mind…" {...inputProps('concern')} />
                    </Field>
                  </>
                )}

                {step === STEP.BIRTH && (
                  <>
                    <StepHeading title="Birth details" subtitle="These details help personalise your guidance." />
                    <Field id="dob" number={6} label="What is your date of birth?" error={errors.dob}>
                      <input type="date" max={todayISO()} {...inputProps('dob')} />
                    </Field>
                    <Field id="birthTime" number={7} label="What is your birth time?" error={errors.birthTime}>
                      <input type="time" {...inputProps('birthTime')} />
                    </Field>
                    <Field id="birthPlace" number={8} label="What is your place of birth?" error={errors.birthPlace}>
                      <input
                        type="text"
                        placeholder="Enter your birth city, state, and country."
                        {...inputProps('birthPlace')}
                      />
                    </Field>
                  </>
                )}
              </div>

              <div className="mt-10 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
                {step > STEP.PERSONAL ? (
                  <button type="button" onClick={back} className="btn-outline">
                    ← Back
                  </button>
                ) : (
                  <span />
                )}
                <button type="submit" className="btn-primary">
                  Continue →
                </button>
              </div>
            </form>
          )}

          {step === STEP.SCHEDULE && (
            <div className="animate-fadeUp">
              <StepHeading
                title="Choose Your Consultation Date and Time"
                subtitle="Select an available date and time for your personal 30-minute consultation."
                large
              />
              <div className="mt-6">
                <CalendlyEmbed url={CALENDLY_URL} onScheduled={handleScheduled} />
              </div>

              <div className="mt-6 rounded-2xl border border-gold-300/60 bg-cream-50 p-5">
                {scheduledViaCalendly ? (
                  <p className="flex items-start gap-3 text-maroon-800">
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-maroon-600 text-cream-50">
                      <Check className="h-4 w-4" />
                    </span>
                    Calendly reported that you scheduled an appointment. Your appointment details are in Calendly&apos;s
                    confirmation email. Continue to payment to complete your booking.
                  </p>
                ) : (
                  <>
                    <p className="text-sm text-maroon-900/70">
                      Please pick a date and time and finish scheduling in the calendar above. If the calendar did not
                      confirm here automatically, or you scheduled in a separate Calendly tab, you can confirm below.
                    </p>
                    <label className="mt-4 flex cursor-pointer items-start gap-3 text-maroon-800">
                      <input
                        type="checkbox"
                        checked={manualScheduleConfirm}
                        onChange={(e) => setManualScheduleConfirm(e.target.checked)}
                        className="mt-1 h-5 w-5 accent-maroon-600"
                      />
                      <span>I have completed scheduling my appointment on Calendly.</span>
                    </label>
                  </>
                )}
              </div>

              <div className="mt-8 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
                <button type="button" onClick={back} className="btn-outline">
                  ← Back
                </button>
                <button
                  type="button"
                  disabled={!canContinueToPayment}
                  onClick={() => setStep(STEP.PAYMENT)}
                  className="btn-primary"
                >
                  Continue to Payment →
                </button>
              </div>
            </div>
          )}

          {step === STEP.PAYMENT && (
            <div className="animate-fadeUp">
              <StepHeading title="Review & Pay" subtitle="Please review your consultation details before paying." large />
              <dl className="mt-6 rounded-2xl border border-cream-300 bg-cream-50 px-5 py-2">
                <SummaryRow label="Full name" value={values.fullName} />
                <SummaryRow label="WhatsApp number" value={values.whatsapp} />
                <SummaryRow label="Email address" value={values.email} />
                <SummaryRow label="Consultation topics" value={values.topics.join(', ')} />
                <SummaryRow label="Birth date" value={formatDate(values.dob)} />
                <SummaryRow label="Birth time" value={formatTime(values.birthTime)} />
                <SummaryRow label="Birthplace" value={values.birthPlace} />
                <SummaryRow label="Appointment" value="As selected on Calendly (see your Calendly confirmation email)" />
                <SummaryRow label="Consultation duration" value={DURATION} />
                <SummaryRow
                  label="Consultation fee"
                  value={<span className="font-serif text-2xl font-semibold text-maroon-700">{FEE}</span>}
                />
              </dl>

              <div className="mt-8 text-center">
                <a
                  href={RAZORPAY_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setStep(STEP.CONFIRMATION)}
                  className="btn-gold w-full text-lg sm:w-auto"
                >
                  Book Your Personal Consultation — Pay {FEE}
                  <ExternalLink className="h-5 w-5" />
                </a>
                <p className="mx-auto mt-4 max-w-xl text-sm text-maroon-900/70">
                  Please complete the payment of ₹501 to proceed with your consultation booking. Keep your payment
                  receipt for reference.
                </p>
                <p className="mx-auto mt-2 max-w-xl text-xs text-maroon-900/50">
                  Payment opens securely on Razorpay in a new tab. This page never asks for card details, UPI PINs, or
                  other payment credentials.
                </p>
              </div>

              <div className="mt-8">
                <button type="button" onClick={back} className="btn-outline">
                  ← Back
                </button>
              </div>
            </div>
          )}

          {step === STEP.CONFIRMATION && (
            <div className="animate-fadeUp py-4 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gold-400/20 text-3xl text-gold-600">
                ✦
              </div>
              <h3 className="mt-6 text-3xl font-semibold text-maroon-700 md:text-4xl">
                One Last Step to Complete Your Booking
              </h3>
              <p className="mx-auto mt-4 max-w-xl text-lg text-maroon-900/75">
                Please complete your ₹501 payment on Razorpay. Your consultation booking is subject to successful
                payment and confirmation of your selected appointment.
              </p>
              <p className="mx-auto mt-4 max-w-xl rounded-2xl border border-cream-300 bg-cream-50 p-4 text-sm text-maroon-900/65">
                This page cannot verify payments or appointments on its own. Your Razorpay receipt and Calendly
                confirmation email are your records of payment and appointment.
              </p>
              <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
                <button type="button" onClick={() => setStep(STEP.PAYMENT)} className="btn-primary">
                  Return to Booking Page
                </button>
                <a href={CALENDLY_URL} target="_blank" rel="noopener noreferrer" className="btn-outline">
                  Open Calendly <ExternalLink className="h-4 w-4" />
                </a>
              </div>
            </div>
          )}
        </div>

        <p className="mx-auto mt-6 max-w-2xl text-center text-xs leading-relaxed text-maroon-900/50">
          Your details stay in this browser tab only and are not saved by this website. Appointments are scheduled
          through Calendly and payments are processed by Razorpay; bookings are confirmed only after successful payment
          and appointment confirmation.
        </p>
      </div>
    </section>
  )
}

function StepHeading({ title, subtitle, large }) {
  return (
    <div className="text-center sm:text-left">
      <h3 className={`font-semibold text-maroon-700 ${large ? 'text-3xl md:text-4xl' : 'text-2xl md:text-3xl'}`}>
        {title}
      </h3>
      {subtitle && <p className="mt-2 text-maroon-900/65">{subtitle}</p>}
    </div>
  )
}

export const Lotus = ({ className = '' }) => (
  <svg viewBox="0 0 64 40" fill="none" stroke="currentColor" strokeWidth="1.5" className={className} aria-hidden>
    <path d="M32 4c6 8 6 18 0 30-6-12-6-22 0-30z" />
    <path d="M32 34C26 24 18 18 8 16c2 10 10 18 24 18z" />
    <path d="M32 34c6-10 14-16 24-18-2 10-10 18-24 18z" />
    <path d="M4 36h56" />
  </svg>
)

export const Check = ({ className = '' }) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className={className} aria-hidden>
    <path fillRule="evenodd" d="M16.7 5.3a1 1 0 010 1.4l-8 8a1 1 0 01-1.4 0l-4-4a1 1 0 011.4-1.4L8 12.6l7.3-7.3a1 1 0 011.4 0z" clipRule="evenodd" />
  </svg>
)

export const ExternalLink = ({ className = '' }) => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <path d="M11 3h6v6M17 3l-8 8M15 12v4a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1h4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
)

import { Link } from 'react-router-dom'
import { BRAND } from '../config.js'
import { scrollToBooking } from '../scroll.js'

export default function SiteHeader({ showCta = true }) {
  return (
    <div className="relative mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
      <Link to="/" className="flex items-center gap-3" aria-label={`${BRAND} home`}>
        <img src="/logo.png" alt={`${BRAND} logo`} width="48" height="49" className="h-11 w-11 sm:h-12 sm:w-12" />
        <span className="font-serif text-2xl font-semibold tracking-wide text-maroon-700">{BRAND}</span>
      </Link>
      {showCta && (
        <button type="button" onClick={scrollToBooking} className="btn-primary hidden px-5 py-2.5 text-sm sm:inline-flex">
          Book Consultation
        </button>
      )}
    </div>
  )
}

import { Link } from 'react-router-dom'
import { BRAND, NAME, ROLE } from '../config.js'

export default function Footer() {
  return (
    <footer className="border-t border-gold-300/40 bg-maroon-800 text-cream-200">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-6 py-10 text-center md:flex-row md:justify-between md:text-left">
        <div className="flex flex-col items-center gap-3 md:flex-row">
          <img src="/logo.png" alt={`${BRAND} logo`} width="48" height="49" className="h-12 w-12" />
          <div>
            <p className="font-serif text-2xl text-gold-300">{NAME}</p>
            <p className="text-sm text-cream-200/70">{ROLE}</p>
          </div>
        </div>
        <nav aria-label="Legal" className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm">
          <Link className="hover:text-gold-300" to="/privacy-policy">Privacy Policy</Link>
          <Link className="hover:text-gold-300" to="/terms">Terms &amp; Conditions</Link>
          <Link className="hover:text-gold-300" to="/refund-policy">Cancellation &amp; Refund Policy</Link>
        </nav>
      </div>
      <p className="border-t border-cream-200/10 py-4 text-center text-xs text-cream-200/60">
        © {new Date().getFullYear()} {BRAND}. All rights reserved.
      </p>
    </footer>
  )
}

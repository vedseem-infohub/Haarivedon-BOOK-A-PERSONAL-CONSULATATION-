import { EXPERIENCE, FEE, NAME, ROLE } from '../config.js'
import { Check, Lotus } from './Icons.jsx'
import SiteHeader from './SiteHeader.jsx'
import { scrollToBooking } from '../scroll.js'

const HIGHLIGHTS = [
  `${EXPERIENCE} years of experience in astrology`,
  'Personalized guidance',
  'Dedicated 30-minute consultation',
  'Simple online booking process',
]

export default function Hero() {
  return (
    <header className="relative overflow-hidden bg-gradient-to-b from-cream-50 via-cream-100 to-cream-200">
      <div aria-hidden className="pointer-events-none absolute -right-32 top-96 h-96 w-96 rounded-full bg-gold-300/30 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-40 -left-24 h-96 w-96 rounded-full bg-maroon-100/60 blur-3xl" />

      <SiteHeader />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
        <div className="animate-fadeUp overflow-hidden rounded-2xl shadow-soft ring-1 ring-gold-300/50 sm:rounded-3xl">
          <img
            src="/poster.jpg"
            alt={`${NAME}, ${ROLE}`}
            width="1600"
            height="900"
            className="block h-auto w-full"
          />
        </div>
      </div>

      <div className="relative mx-auto max-w-6xl px-6 pb-20 pt-12 md:pb-28 md:pt-16">
        <div className="grid items-center gap-12 md:grid-cols-[1.25fr_1fr]">
          <div className="animate-fadeUp">
            <span className="inline-flex items-center gap-2 rounded-full border border-gold-400/60 bg-white/70 px-4 py-1.5 text-sm font-semibold text-maroon-700">
              <span className="font-serif text-lg text-gold-600">{EXPERIENCE}</span> Years of Experience
            </span>
            <h1 className="mt-5 text-4xl font-semibold leading-tight text-maroon-700 sm:text-5xl lg:text-6xl">
              Find Clarity. Discover Direction.{' '}
              <span className="italic text-gold-600">Transform Your Tomorrow.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-maroon-900/75">
              Have questions about your future, career, relationships, family, or personal life? Book a personal
              consultation with {NAME} to discuss your concerns and explore personalized guidance, suggestions, and
              suitable remedies.
            </p>

            <ul className="mt-8 space-y-3">
              {HIGHLIGHTS.map((h) => (
                <li key={h} className="flex items-center gap-3 text-maroon-900/85">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gold-400/25 text-gold-700">
                    <Check className="h-4 w-4" />
                  </span>
                  {h}
                </li>
              ))}
            </ul>

            <div className="mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <button type="button" onClick={scrollToBooking} className="btn-primary text-lg">
                Book Your Personal Consultation
              </button>
              <p className="text-maroon-900/70">
                Consultation fee: <span className="font-serif text-2xl font-semibold text-maroon-700">{FEE}</span>
              </p>
            </div>
          </div>

          <figure className="card animate-fadeUp p-8 text-center [animation-delay:150ms] md:p-10">
            <Lotus className="mx-auto h-12 w-20 text-gold-500" />
            <blockquote className="mt-6 font-serif text-2xl italic leading-snug text-maroon-700 md:text-3xl">
              “Sometimes, the right guidance can help you see a new direction when life feels uncertain.”
            </blockquote>
            <figcaption className="mt-6 text-sm font-medium uppercase tracking-widest text-gold-600">— {NAME}</figcaption>
            <div className="mt-8 grid grid-cols-3 divide-x divide-gold-300/50 rounded-2xl bg-cream-100 py-4">
              <Stat value={EXPERIENCE} label="Years" />
              <Stat value="30" label="Minutes" />
              <Stat value={FEE} label="Fee" />
            </div>
          </figure>
        </div>
      </div>
    </header>
  )
}

function Stat({ value, label }) {
  return (
    <div>
      <p className="font-serif text-3xl font-semibold text-maroon-700">{value}</p>
      <p className="text-xs uppercase tracking-wider text-maroon-900/60">{label}</p>
    </div>
  )
}

import { Link } from 'react-router-dom'
import { NAME } from '../config.js'
import SiteHeader from '../components/SiteHeader.jsx'

const POLICIES = {
  privacy: {
    title: 'Privacy Policy',
    intro:
      `This page is a placeholder. The final Privacy Policy for consultations with ${NAME} will be published here.`,
    points: [
      'The details you enter in the consultation form stay in your browser while the page is open and are not stored by this website or saved to local storage.',
      'Appointment scheduling is handled by Calendly and payments are handled by Razorpay. Information you submit on those services is governed by their respective privacy policies.',
      'This website does not collect card details, UPI PINs, or any payment credentials.',
    ],
  },
  terms: {
    title: 'Terms & Conditions',
    intro:
      `This page is a placeholder. The final Terms & Conditions for consultations with ${NAME} will be published here.`,
    points: [
      'Each consultation is a 30-minute personal session for a fee of ₹501.',
      'A booking is subject to successful payment and confirmation of the selected appointment.',
      'Guidance, suggestions, and remedies shared during a consultation are personal in nature and are not a substitute for professional medical, legal, or financial advice.',
    ],
  },
  refund: {
    title: 'Cancellation & Refund Policy',
    intro:
      `This page is a placeholder. The final Cancellation & Refund Policy for consultations with ${NAME} will be published here.`,
    points: [
      'Appointment rescheduling or cancellation can be requested using the links in your Calendly confirmation email.',
      'Refund eligibility and timelines will be described here once finalised.',
      'Please keep your Razorpay payment receipt for reference in any refund request.',
    ],
  },
}

export default function Policy({ type }) {
  const policy = POLICIES[type]
  return (
    <>
    <SiteHeader showCta={false} />
    <div className="mx-auto max-w-3xl px-6 pb-16 pt-8 md:pb-24">
      <Link to="/" className="text-sm font-medium text-maroon-600 hover:text-maroon-800">
        ← Back to home
      </Link>
      <h1 className="mt-6 text-4xl font-semibold text-maroon-700 md:text-5xl">{policy.title}</h1>
      <div className="mt-3 h-px w-24 bg-gold-400" />
      <p className="mt-8 rounded-2xl border border-gold-300/60 bg-cream-50 p-5 text-maroon-900/80">{policy.intro}</p>
      <ul className="mt-8 space-y-4">
        {policy.points.map((p) => (
          <li key={p} className="flex gap-3 text-maroon-900/80">
            <span aria-hidden className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
            <span>{p}</span>
          </li>
        ))}
      </ul>
    </div>
    </>
  )
}

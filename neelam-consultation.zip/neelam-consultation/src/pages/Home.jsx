import Hero from '../components/Hero.jsx'
import About from '../components/About.jsx'
import BookingFlow from '../components/BookingFlow.jsx'

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <BookingFlow />
    </>
  )
}
